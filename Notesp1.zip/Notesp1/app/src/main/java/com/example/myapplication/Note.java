package com.example.myapplication;

public class Note {
    private int noteID;
    private String subject;
    private String note;
    private int priority;
    private Long time;

    public Note (){
        noteID = -1;
    }

    public int getNoteID(){
        return noteID;
    }

    public void setNoteID(int i){
        noteID=i;
    }

    public String getSubject(){
        return subject;
    }

    public void setSubject(String s){
        subject = s;
    }

    public String getNote(){
        return note;
    }

    public void setNote(String s){
        note = s;
    }

    public int getPriority(){
        return priority;
    }

    public void setPriority(int s){
        priority = s;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }
}


